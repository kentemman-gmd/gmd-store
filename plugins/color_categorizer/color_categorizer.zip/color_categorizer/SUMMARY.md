# Table of contents

* [Color Categorizer Plugin](README.md)
* [Apply QML Style Manager](apply-qml-style-manager.md)
